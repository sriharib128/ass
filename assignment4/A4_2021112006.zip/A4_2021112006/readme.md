# Section 1

### question 1
- gcc 1.c
- ./a.out 1.csv

### question 2
- gcc 2.c
- ./a.out 2.csv

### question 3
- gcc 3.c
- ./a.out 3_pi.csv

##### Plots folder contains the matplotlib code and the csv data files used for plotting the graphs.

---
# Section 2

### question 4a
- gcc 4a.c
- ./a.out data.txt mean.txt

### question 4b
- gcc 4b.c
- ./a.out data.txt mean.txt var.txt

### question 4c
- gcc 4c.c
- ./a.out data.txt mean.txt percent.txt
  
### calculating approximate and actual mean
-  open var_4_b folder
	- gcc var.c
	- ./a.out data.txt var.csv

---
# Section 3

### question 5a
- gcc 5a.c
- ./a.out

### question 5b
- gcc 5b.c
- ./a.out

### question 5c
- gcc 5c_encrypt.c
- ./a.out msg.txt key.txt e_out.txt
- gcc 5c_decrypt.c
- ./a.out key.txt e_out.txt d_out.txt

##### msg.txt can be replaced with any file type (even greater 1e6 bits)

---
# Section 4

### question 6
- gcc 6.c
- ./a.out c_f.txt f1.txt f2.txt f3.txt ----- fn.txt

### question 7
- gcc 7.c
- ./a.out w_f.txt f1.txt f2.txt f3.txt ------ fn.txt

### question 8
- gcc 8.c
- ./a.out file1.txt file2.txt sorted.txt

### question 9
- open 9_large_file_sort folder
	- gcc main.c
	- ./a.out input_file.txt o_p_sorted.txt

###### sorted every 1e5 words (value of N can be changed in include.h file) (max word length <=100) 

---
